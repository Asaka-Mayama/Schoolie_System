<?php
/**
 * logout.php — Destroy the admin session and return to the login page.
 */
require_once __DIR__ . '/config.php';

// Clear all session data.
$_SESSION = [];

// Expire the session cookie on the client side as well.
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();

header('Location: login.php');
exit;
