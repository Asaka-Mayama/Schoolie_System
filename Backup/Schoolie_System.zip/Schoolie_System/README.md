# Schoolie — School & Office Supplies Inventory System

A single-user (admin) inventory web app with a **Shopee-style UI**, built with
**plain HTML/CSS, procedural PHP (mysqli) and MySQL** — ready to run on XAMPP.
No CSS frameworks.

## What it looks like

- **Market storefront** (`index.php`): one continuous orange header — utility
  strip (Marketplace + admin menu), Schoolie logo, search bar and a
  **Categories** quick-link row — plus the "DAILY DISCOVER" product-card grid
  (image, ₱ price, stock, category).
- **Admin dropdown**: hover (or tap) the **admin** name in the top bar to open
  a navigation menu — My Dashboard, Manage Products, Add New Product, Logout —
  like Shopee's account dropdown.
- **Seller Centre** (dashboard.php / products.php / add.php / edit.php):
  sidebar menu with **Dashboard**, **Manage Products** and **Add New Product**,
  so adding or editing products is never mixed with the market page.
- Fully **responsive**: verified with no horizontal overflow at 320, 375, 768
  and 1280 px (tables scroll inside their card on small screens, the sidebar
  becomes a horizontal menu bar, the market grid drops to 2 columns).

## Setup (XAMPP)

1. Copy the whole `Schoolie_System` folder into your XAMPP `htdocs` folder
   (e.g. `C:\xampp\htdocs\Schoolie_System`).
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Import the database:
   - Open <http://localhost/phpmyadmin> → **Import** → choose `database.sql`
     → Go. (Or CLI: `mysql -u root < database.sql`.)
4. Open <http://localhost/Schoolie_System/> and log in:
   - **Username:** `admin`
   - **Password:** `admin123`

The admin account lives in the `users` table of the **`Schoolie_db`** database
(password stored as a `password_hash()` bcrypt digest and checked with
`password_verify()`).

## Files

| File | Purpose |
| --- | --- |
| `database.sql` | Creates `Schoolie_db` with `users` (admin account) and `products` (8 sample items) |
| `config.php` | MySQL connection (localhost / root / empty password) + shared helpers |
| `login.php` | Schoolie sign-in; verifies credentials against the `users` table |
| `logout.php` | Destroys the session, redirects to `login.php` |
| `index.php` | Market storefront: product cards, search, Categories quick links |
| `nav.php` | Shared Seller Centre topbar/sidebar + the admin hover dropdown + breadcrumbs |
| `dashboard.php` | Seller Centre dashboard: summary cards, low-stock watchlist, quick actions |
| `products.php` | Manage Products: search + category filter + table with Edit/Delete |
| `add.php` | Add a product (with image upload to `uploads/`) |
| `edit.php` | Update a product (optionally replace its image) |
| `delete.php` | Delete a product and its image file |
| `style.css` | Custom Shopee-style responsive CSS (no frameworks) |
| `uploads/logo/logo.png` | Schoolie logo shown in the header and sign-in page |
| `uploads/` | Uploaded product images (auto-created if missing) |

## Notes

- All pages redirect to `login.php` when not authenticated.
- Low-stock threshold: `stock <= 20` (changeable via `LOW_STOCK_LEVEL` in `config.php`).
- Images: JPG/PNG/GIF/WebP, max 5 MB; validated and stored with safe unique names.
- **Logo**: replace `uploads/logo/logo.png` with your own PNG (keep the same
  file name) and it appears everywhere automatically.
- Peso amounts are formatted as ₱ (Philippine Peso).
