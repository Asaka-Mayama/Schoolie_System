<?php
/**
 * add.php — Seller Centre: Add a new product (optional image upload to uploads/).
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/nav.php';
require_login();

$errors = [];
$old = ['item_code' => '', 'item_name' => '', 'category' => '', 'unit' => '', 'price' => '', 'stock' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (array_keys($old) as $field) {
        $old[$field] = trim((string) ($_POST[$field] ?? ''));
    }

    $itemCode = $old['item_code'];
    $itemName = $old['item_name'];
    $category = $old['category'];
    $unit     = $old['unit'];
    $price    = $old['price'];
    $stock    = $old['stock'];

    // ---- validation -------------------------------------------------
    if ($itemCode === '') {
        $errors[] = 'Item code is required.';
    } elseif (mb_strlen($itemCode) > 20) {
        $errors[] = 'Item code must be 20 characters or fewer.';
    }

    if ($itemName === '') {
        $errors[] = 'Item name is required.';
    } elseif (mb_strlen($itemName) > 100) {
        $errors[] = 'Item name must be 100 characters or fewer.';
    }

    if (!in_array($category, $CATEGORIES, true)) {
        $errors[] = 'Please choose a valid category.';
    } elseif (!in_array($unit, $CATEGORY_UNITS[$category] ?? [], true)) {
        $errors[] = 'Please choose a valid unit for ' . $category
            . ' (allowed: ' . implode(', ', $CATEGORY_UNITS[$category]) . ').';
    }

    if ($price === '' || !is_numeric($price) || (float) $price < 0) {
        $errors[] = 'Enter a valid price (0 or greater).';
    }
    if ($stock === '' || !ctype_digit($stock)) {
        $errors[] = 'Enter a valid whole-number stock quantity (0 or greater).';
    }

    // ---- unique item code -------------------------------------------
    if (!$errors) {
        $chk = mysqli_prepare($conn, 'SELECT id FROM products WHERE item_code = ?');
        mysqli_stmt_bind_param($chk, 's', $itemCode);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) > 0) {
            $errors[] = 'Item code "' . $itemCode . '" is already in use. Item codes must be unique.';
        }
    }

    // ---- image upload (optional) -------------------------------------
    $image = null;
    if (!$errors) {
        $image = handle_image_upload($_FILES['image'] ?? null, $imgError);
        if ($imgError !== null) {
            $errors[] = $imgError;
        }
    }

    // ---- insert ------------------------------------------------------
    if (!$errors) {
        $stmt = mysqli_prepare(
            $conn,
            'INSERT INTO products (item_code, item_name, category, unit, price, stock, image)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $priceVal  = (float) $price;
        $stockVal  = (int) $stock;
        $imageVal  = $image ?? '';
        mysqli_stmt_bind_param($stmt, 'ssssdis', $itemCode, $itemName, $category, $unit, $priceVal, $stockVal, $imageVal);
        mysqli_stmt_execute($stmt);

        header('Location: products.php?added=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add New Product — Schoolie</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php render_seller_nav('add'); ?>

<?= seller_breadcrumb([['Seller Centre', 'dashboard.php'], ['Products', 'products.php'], ['Add New Product', '']]) ?>

<div class="page-head">
    <div>
        <h1>Add New Product</h1>
        <p class="page-sub">Fill in the details below. Only the image is optional.</p>
    </div>
</div>

<?php if ($errors): ?>
    <div class="alert alert-error" role="alert">
        <strong>Please fix the following:</strong>
        <ul>
            <?php foreach ($errors as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="form-wrap">
    <form class="form-card" method="post" action="add.php" enctype="multipart/form-data" novalidate>
        <div class="form-card-head">Product Information</div>

        <div class="form-grid">
            <div class="field">
                <label for="item_code">Item Code <span class="req">*</span></label>
                <input type="text" id="item_code" name="item_code" maxlength="20"
                       value="<?= htmlspecialchars($old['item_code'], ENT_QUOTES) ?>"
                       placeholder="e.g. SUP-009" required>
            </div>

            <div class="field">
                <label for="category">Category <span class="req">*</span></label>
                <select id="category" name="category" required>
                    <option value="">&mdash; Select category &mdash;</option>
                    <?php foreach ($CATEGORIES as $cat): ?>
                        <option value="<?= htmlspecialchars($cat, ENT_QUOTES) ?>"
                            <?= $old['category'] === $cat ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat, ENT_QUOTES) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field span-2">
                <label for="item_name">Item Name <span class="req">*</span></label>
                <input type="text" id="item_name" name="item_name" maxlength="100"
                       value="<?= htmlspecialchars($old['item_name'], ENT_QUOTES) ?>"
                       placeholder="e.g. Gel Pen (0.5mm, Blue)" required>
            </div>

            <div class="field">
                <label for="unit">Unit <span class="req">*</span></label>
                <?php $selCategory = in_array($old['category'], $CATEGORIES, true) ? $old['category'] : ''; ?>
                <select id="unit" name="unit" required aria-describedby="unit-help"
                        <?= $selCategory === '' ? 'disabled' : '' ?>>
                    <?php if ($selCategory === ''): ?>
                        <option value="">&mdash; Select category first &mdash;</option>
                    <?php else: ?>
                        <option value="">&mdash; Select unit &mdash;</option>
                        <?php foreach ($CATEGORY_UNITS[$selCategory] as $u): ?>
                            <option value="<?= htmlspecialchars($u, ENT_QUOTES) ?>"
                                <?= $old['unit'] === $u ? 'selected' : '' ?>>
                                <?= htmlspecialchars($u, ENT_QUOTES) ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
                <p class="help-text" id="unit-help">Choose a category first &mdash; the unit list depends on it.</p>
            </div>

            <div class="field">
                <label for="price">Price (&#8369;) <span class="req">*</span></label>
                <input type="number" id="price" name="price" min="0" step="0.01"
                       value="<?= htmlspecialchars($old['price'], ENT_QUOTES) ?>"
                       placeholder="e.g. 125.50" required>
            </div>

            <div class="field">
                <label for="stock">Stock Quantity <span class="req">*</span></label>
                <input type="number" id="stock" name="stock" min="0" step="1"
                       value="<?= htmlspecialchars($old['stock'], ENT_QUOTES) ?>"
                       placeholder="e.g. 50" required>
            </div>

            <div class="field span-2">
                <label for="image">Product Image</label>
                <input type="file" id="image" name="image" accept="image/*">
                <p class="help-text">Optional. JPG, PNG, GIF or WebP, up to 5 MB.
                    Saved into the <code>uploads/</code> folder.</p>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Save Product</button>
            <a class="btn btn-ghost" href="products.php">Cancel</a>
        </div>
    </form>
</div>

<?php render_seller_footer(); ?>

<script>
(function () {
    // Category -> allowed units (single source of truth: config.php).
    var CATEGORY_UNITS = <?= json_encode($CATEGORY_UNITS, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
    var catSel   = document.getElementById('category');
    var unitSel  = document.getElementById('unit');
    var unitHelp = document.getElementById('unit-help');
    if (!catSel || !unitSel) { return; }

    function syncUnit() {
        var cat   = catSel.value;
        var units = CATEGORY_UNITS[cat] || [];
        var prev  = unitSel.getAttribute('data-prev') || unitSel.value;

        if (units.length === 0) {
            // No category picked yet: keep the Unit dropdown disabled.
            unitSel.disabled = true;
            unitSel.innerHTML = '';
            unitSel.appendChild(new Option('\u2014 Select category first \u2014', ''));
            if (unitHelp) {
                unitHelp.textContent = 'Choose a category first \u2014 the unit list depends on it.';
            }
            return;
        }

        // Enable, clear old options, add the placeholder, then the allowed units.
        unitSel.disabled = false;
        unitSel.innerHTML = '';
        unitSel.appendChild(new Option('\u2014 Select unit \u2014', ''));
        units.forEach(function (u) {
            unitSel.appendChild(new Option(u, u));
        });

        // Keep the previous choice when it is still valid for this category.
        if (prev && units.indexOf(prev) !== -1) {
            unitSel.value = prev;
        }
        if (unitHelp) {
            unitHelp.textContent = 'Allowed for ' + cat + ': ' + units.join(', ') + '.';
        }
    }

    catSel.addEventListener('change', syncUnit);

    // Remember the current unit so switching back can restore it.
    unitSel.addEventListener('change', function () {
        unitSel.setAttribute('data-prev', unitSel.value);
    });

    // Sync the initial state (also corrects the markup after an error reload,
    // where the server already rendered the selected unit).
    if (unitSel.value) {
        unitSel.setAttribute('data-prev', unitSel.value);
    }
    syncUnit();
})();
</script>

</body>
</html>
