<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/nav.php';
require_login();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
if ($id <= 0) {
    header('Location: products.php');
    exit;
}

$stmt = mysqli_prepare(
    $conn,
    'SELECT id, item_code, item_name, category, unit, price, stock, image
     FROM products WHERE id = ?'
);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$product = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$product) {
    header('Location: products.php');
    exit;
}

$errors = [];
$old = [
    'item_code' => (string) $product['item_code'],
    'item_name' => (string) $product['item_name'],
    'category'  => (string) $product['category'],
    'unit'      => (string) $product['unit'],
    'price'     => (string) $product['price'],
    'stock'     => (string) $product['stock'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (array_keys($old) as $field) {
        $old[$field] = trim((string) ($_POST[$field] ?? ''));
    }

    $itemCode = $old['item_code'];
    $itemName = $old['item_name'];
    $category = $old['category'];
    $unit     = $old['unit'];
    $price    = $old['price'];
    $stock    = $old['stock'];

    if ($itemCode === '') {
        $errors[] = 'Item code is required.';
    } elseif (mb_strlen($itemCode) > 20) {
        $errors[] = 'Item code must be 20 characters or fewer.';
    }

    if ($itemName === '') {
        $errors[] = 'Item name is required.';
    } elseif (mb_strlen($itemName) > 100) {
        $errors[] = 'Item name must be 100 characters or fewer.';
    }

    if (!in_array($category, $CATEGORIES, true)) {
        $errors[] = 'Please choose a valid category.';
    }
    if (!in_array($unit, $UNITS, true)) {
        $errors[] = 'Please choose a valid unit.';
    }

    if ($price === '' || !is_numeric($price) || (float) $price < 0) {
        $errors[] = 'Enter a valid price (0 or greater).';
    }
    if ($stock === '' || !ctype_digit($stock)) {
        $errors[] = 'Enter a valid whole-number stock quantity (0 or greater).';
    }

    if (!$errors) {
        $chk = mysqli_prepare($conn, 'SELECT id FROM products WHERE item_code = ? AND id <> ?');
        mysqli_stmt_bind_param($chk, 'si', $itemCode, $id);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) > 0) {
            $errors[] = 'Item code "' . $itemCode . '" is already in use. Item codes must be unique.';
        }
    }

    $newImage = null;
    if (!$errors) {
        $newImage = handle_image_upload($_FILES['image'] ?? null, $imgError);
        if ($imgError !== null) {
            $errors[] = $imgError;
        }
    }

    if (!$errors) {
        $imageVal = $newImage !== null ? $newImage : (string) $product['image'];

        $stmt = mysqli_prepare(
            $conn,
            'UPDATE products
             SET item_code = ?, item_name = ?, category = ?, unit = ?, price = ?, stock = ?, image = ?
             WHERE id = ?'
        );
        $priceVal = (float) $price;
        $stockVal = (int) $stock;
        mysqli_stmt_bind_param($stmt, 'ssssdisi', $itemCode, $itemName, $category, $unit, $priceVal, $stockVal, $imageVal, $id);
        mysqli_stmt_execute($stmt);

        if ($newImage !== null) {
            $oldPath = upload_path((string) $product['image']);
            if ($oldPath !== null) {
                @unlink($oldPath);
            }
        }

        header('Location: products.php?updated=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit <?= htmlspecialchars($old['item_code']) ?> — Schoolie</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php render_seller_nav('products'); ?>

<?= seller_breadcrumb([['Seller Centre', 'dashboard.php'], ['Products', 'products.php'], ['Edit: ' . $old['item_code'], '']]) ?>

<div class="page-head">
    <div>
        <h1>Edit Product</h1>
        <p class="page-sub">Updating <strong><?= htmlspecialchars($old['item_code']) ?></strong>
            &mdash; <?= htmlspecialchars($old['item_name']) ?></p>
    </div>
</div>

<?php if ($errors): ?>
    <div class="alert alert-error" role="alert">
        <strong>Please fix the following:</strong>
        <ul>
            <?php foreach ($errors as $err): ?>
                <li><?= htmlspecialchars($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="form-wrap">
    <form class="form-card" method="post" action="edit.php" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="id" value="<?= (int) $product['id'] ?>">
        <div class="form-card-head">Product Information</div>

        <div class="form-grid">
            <div class="field">
                <label for="item_code">Item Code <span class="req">*</span></label>
                <input type="text" id="item_code" name="item_code" maxlength="20"
                       value="<?= htmlspecialchars($old['item_code'], ENT_QUOTES) ?>" required>
            </div>

            <div class="field">
                <label for="category">Category <span class="req">*</span></label>
                <select id="category" name="category" required>
                    <option value="">&mdash; Select category &mdash;</option>
                    <?php foreach ($CATEGORIES as $cat): ?>
                        <option value="<?= htmlspecialchars($cat, ENT_QUOTES) ?>"
                            <?= $old['category'] === $cat ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat, ENT_QUOTES) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field span-2">
                <label for="item_name">Item Name <span class="req">*</span></label>
                <input type="text" id="item_name" name="item_name" maxlength="100"
                       value="<?= htmlspecialchars($old['item_name'], ENT_QUOTES) ?>" required>
            </div>

            <div class="field">
                <label for="unit">Unit <span class="req">*</span></label>
                <select id="unit" name="unit" required>
                    <option value="">&mdash; Select unit &mdash;</option>
                    <?php foreach ($UNITS as $u): ?>
                        <option value="<?= htmlspecialchars($u, ENT_QUOTES) ?>"
                            <?= $old['unit'] === $u ? 'selected' : '' ?>>
                            <?= htmlspecialchars($u, ENT_QUOTES) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label for="price">Price (&#8369;) <span class="req">*</span></label>
                <input type="number" id="price" name="price" min="0" step="0.01"
                       value="<?= htmlspecialchars($old['price'], ENT_QUOTES) ?>" required>
            </div>

            <div class="field">
                <label for="stock">Stock Quantity <span class="req">*</span></label>
                <input type="number" id="stock" name="stock" min="0" step="1"
                       value="<?= htmlspecialchars($old['stock'], ENT_QUOTES) ?>" required>
            </div>

            <div class="field span-2">
                <label for="image">Product Image</label>
                <div class="image-preview">
                    <?= image_cell($product['image'], (string) $product['item_name']) ?>
                    <span class="help-text">
                        <?php if (upload_path($product['image']) !== null): ?>
                            Current image shown above. Leave the file input empty to keep it &mdash;
                            choosing a new file replaces it.
                        <?php else: ?>
                            No image uploaded yet. Choose a file to add one
                            (JPG, PNG, GIF or WebP, up to 5 MB).
                        <?php endif; ?>
                    </span>
                </div>
                <input type="file" id="image" name="image" accept="image/*">
                <p class="help-text">Replacing the image also deletes the old file from
                    <code>uploads/</code>.</p>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Save Changes</button>
            <a class="btn btn-ghost" href="products.php">Cancel</a>
        </div>
    </form>
</div>

<?php render_seller_footer(); ?>

</body>
</html>
