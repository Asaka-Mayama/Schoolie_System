<?php

require_once __DIR__ . '/config.php';
require_login();

$id = (int) ($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: products.php');
    exit;
}

$stmt = mysqli_prepare($conn, 'SELECT image FROM products WHERE id = ?');
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$row   = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
$image = $row['image'] ?? null;

$del = mysqli_prepare($conn, 'DELETE FROM products WHERE id = ?');
mysqli_stmt_bind_param($del, 'i', $id);
mysqli_stmt_execute($del);

if ($image !== null && $image !== '') {
    $path = upload_path($image);
    if ($path !== null) {
        @unlink($path);
    }
}

header('Location: products.php?deleted=1');
exit;
