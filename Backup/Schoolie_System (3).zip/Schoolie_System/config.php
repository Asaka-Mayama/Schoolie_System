<?php
/**
 * config.php — Central configuration for Schoolie (XAMPP).
 *
 * Contains:
 *   - MySQL connection (procedural mysqli)  : host localhost, user root, empty password
 *   - Session bootstrap + login helpers
 *   - Shared option lists (categories / units)
 *   - Product image upload + rendering helpers
 */

// ---------------------------------------------------------------- session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---------------------------------------------------------------- database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'Schoolie_db');

// PHP 8.1+ throws mysqli_sql_exception on failure (and "@" does not
// suppress exceptions), so the connection is wrapped in try/catch.
try {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
} catch (Throwable $e) {
    $conn = false;
}

if (!$conn) {
    http_response_code(500);
    die(
        '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>Database Error — Schoolie</title>'
        . '<style>body{font-family:system-ui,-apple-system,"Segoe UI",Arial,sans-serif;background:#f1f5f9;'
        . 'display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;color:#0f172a}'
        . '.box{background:#fff;border-radius:14px;padding:2rem 2.25rem;box-shadow:0 10px 30px rgba(2,6,23,.08);'
        . 'max-width:540px;margin:1rem}h1{font-size:1.15rem;color:#dc2626;margin:0 0 .75rem}'
        . 'p{color:#475569;line-height:1.6;margin:.3rem 0}code{background:#f1f5f9;padding:.15rem .45rem;'
        . 'border-radius:6px;font-size:.9em}</style></head><body>'
        . '<div class="box"><h1>&#9888; Database connection failed</h1>'
        . '<p>Could not connect to MySQL database <code>' . DB_NAME . '</code>.</p>'
        . '<p>Checklist: start <strong>MySQL</strong> in the XAMPP Control Panel, then import '
        . '<code>database.sql</code> via phpMyAdmin (<code>http://localhost/phpmyadmin</code> &rarr; Import).</p>'
        . '</div></body></html>'
    );
}

mysqli_set_charset($conn, 'utf8mb4');

// ------------------------------------------------- shared option lists
$CATEGORIES = ['Writing', 'Paper', 'Desk Accessories', 'Correction & Adhesives'];
$UNITS      = ['piece', 'box', 'ream', 'pad', 'pack'];

$CATEGORY_UNITS = [
    'Writing'                => ['piece', 'box', 'pack'],
    'Paper'                  => ['ream', 'pad', 'piece', 'pack'],
    'Desk Accessories'       => ['piece', 'box', 'pack'],
    'Correction & Adhesives' => ['piece', 'box', 'pack'],
];

// Low-stock threshold used on the dashboard (stock <= 20 counts as low)
define('LOW_STOCK_LEVEL', 20);

// ------------------------------------------------------- auth helpers
/** True when the admin is signed in. */
function is_logged_in(): bool
{
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

/** Redirect unauthenticated visitors to login.php and stop the script. */
function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

// ------------------------------------------------------- image helpers
/**
 * Validate + save an uploaded product image into the uploads/ folder.
 *
 * Returns the stored filename, or null when no file was chosen.
 * On failure, fills $error with a friendly message.
 */
function handle_image_upload(?array $file, ?string &$error = null): ?string
{
    $error = null;

    // No image chosen — perfectly fine, the placeholder will be shown.
    if ($file === null || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Image upload failed (error code ' . (int) $file['error'] . '). Please try again.';
        return null;
    }
    if ($file['size'] <= 0 || $file['size'] > 5 * 1024 * 1024) {
        $error = 'Image must be between 1 byte and 5 MB.';
        return null;
    }

    // Verify the file really is an image (and pin the extension to its real type).
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
    ];
    $info = @getimagesize($file['tmp_name']);
    if ($info === false || !isset($allowed[$info['mime']])) {
        $error = 'Only JPG, PNG, GIF or WebP image files are allowed.';
        return null;
    }

    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true); // auto-create the uploads/ directory
    }

    // Build a safe, unique filename (original name is sanitised, never trusted).
    $base = pathinfo($file['name'], PATHINFO_FILENAME);
    $base = trim(preg_replace('/[^A-Za-z0-9_-]+/', '_', (string) $base), '_');
    if ($base === '') {
        $base = 'product';
    }
    $filename = time() . '_' . bin2hex(random_bytes(4)) . '_' . $base . '.' . $allowed[$info['mime']];

    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $filename)) {
        $error = 'Could not save the uploaded image. Check the permissions of the uploads/ folder.';
        return null;
    }
    return $filename;
}

/** Absolute filesystem path of a stored image, or null when it does not exist. */
function upload_path(?string $filename): ?string
{
    if ($filename === null || $filename === '') {
        return null;
    }
    $path = __DIR__ . '/uploads/' . basename($filename); // basename() blocks path traversal
    return is_file($path) ? $path : null;
}

/**
 * HTML for a product image cell: a thumbnail when the file exists,
 * otherwise a clean SVG placeholder box.
 */
function image_cell(?string $filename, string $itemName): string
{
    if (upload_path($filename) !== null) {
        $src = 'uploads/' . rawurlencode(basename($filename));
        return '<img class="thumb" src="' . $src . '" alt="'
            . htmlspecialchars($itemName, ENT_QUOTES) . '">';
    }
    return '<div class="thumb thumb-empty" title="No image">'
        . '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor"'
        . ' stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/>'
        . '<path d="M21 16l-4.5-4.5L9 19"/></svg></div>';
}
