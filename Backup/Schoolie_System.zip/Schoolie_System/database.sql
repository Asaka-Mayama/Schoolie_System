-- =====================================================================
-- Schoolie — School & Office Supplies Inventory System
-- Database : Schoolie_db
-- Platform : XAMPP (MySQL / MariaDB)
--
-- How to import:
--   1) phpMyAdmin : http://localhost/phpmyadmin  ->  Import  ->  choose this file
--   2) CLI        : mysql -u root < database.sql
--
-- Default admin login (stored in the users table):
--   username : admin
--   password : admin123
-- =====================================================================

CREATE DATABASE IF NOT EXISTS Schoolie_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE Schoolie_db;

DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

-- ---------------------------------------------------------------------
-- users table — admin accounts for signing in
--   password is stored as a PHP password_hash() bcrypt digest
--   default account: admin / admin123
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id            INT           AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)   NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,
  created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE         = utf8mb4_unicode_ci;

INSERT INTO users (username, password_hash) VALUES
('admin', '$2y$10$VMsX8mdmWf52htvdkDFgte2qIEZHdALznyLSne0m5H/S1r8RnqHP.');

-- ---------------------------------------------------------------------
-- products table
--   category options : Writing | Paper | Desk Accessories | Correction & Adhesives
--   unit options     : piece | box | ream | pad | pack
--   image            : filename stored inside uploads/ (empty = placeholder)
-- ---------------------------------------------------------------------
CREATE TABLE products (
  id        INT           AUTO_INCREMENT PRIMARY KEY,
  item_code VARCHAR(20)   UNIQUE NOT NULL,
  item_name VARCHAR(100)  NOT NULL,
  category  VARCHAR(50)   NOT NULL,
  unit      VARCHAR(20)   NOT NULL,
  price     DECIMAL(10,2) NOT NULL,
  stock     INT           NOT NULL,
  image     VARCHAR(255)  NOT NULL DEFAULT ''
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4
  COLLATE         = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Sample products (image column left empty so the placeholder shows)
-- ---------------------------------------------------------------------
INSERT INTO products (item_code, item_name, category, unit, price, stock, image) VALUES
('SUP-001', 'HBW Ballpen (Black)',         'Writing',                'piece', 12.00,  120, ''),
('SUP-002', 'A4 Bond Paper (80gsm)',       'Paper',                  'ream',  240.00,  35, ''),
('SUP-003', 'Yellow Pad Paper',            'Paper',                  'pad',   45.00,   60, ''),
('SUP-004', 'Heavy Duty Stapler #35',      'Desk Accessories',       'piece', 185.00,  15, ''),
('SUP-005', 'Spiral Composition Notebook', 'Paper',                  'piece', 35.00,   80, ''),
('SUP-006', 'Whiteboard Marker (Blue)',    'Writing',                'piece', 48.00,   45, ''),
('SUP-007', 'Correction Tape (5mm x 8m)',  'Correction & Adhesives', 'piece', 30.00,   50, ''),
('SUP-008', 'Paper Clips (Vinyl Coated)',  'Desk Accessories',       'box',   25.00,   40, '');
